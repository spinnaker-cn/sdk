package com.hecloud.sdk.elb.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 * @author 硝酸铜
 * @date 2022/4/28
 */
@Data
@With
@ToString
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
public class ListenerRef {
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="id")

    private String id;

}
