package com.hecloud.sdk.elb.region;
import com.huaweicloud.sdk.core.region.Region;

public class ElbRegion {
    public static Region CN_NORTH_BEIJING_2 = new Region("cidc-rp-11", "https://elb.cidc-rp-11.joint.cmecloud.cn");
    public static Region CN_EAST_WUXI = new Region("cidc-rp-12", "https://elb.cidc-rp-12.joint.cmecloud.cn");
    public static Region CN_EAST_FUZHOU = new Region("cidc-rp-13", "https://elb.cidc-rp-13.joint.cmecloud.cn");
    public static Region SOUTHEAST_SHENYANG = new Region("cidc-rp-19", "https://elb.cidc-rp-19.joint.cmecloud.cn");
    public static Region CN_EAST_NINGBO = new Region("cidc-rp-2000", "https://elb.cidc-rp-2000.joint.cmecloud.cn");

}
