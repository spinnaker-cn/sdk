package com.hecloud.sdk.elb.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.*;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * @author 王凯
 * @date 2022/4/28
 */

@Data
@EqualsAndHashCode()
@With
@AllArgsConstructor
@NoArgsConstructor
public class Healthmonitors {
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="id")
    private String id;


    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="timeout")
    private Integer timeout;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="max_retries")
    private Integer maxRetries;


    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="url_path")
    private String urlPath;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="domain_name")
    private String domainName;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="delay")
    private Integer delay;

    public static final class StatusEnum {

        public static final Healthmonitors.StatusEnum NO_MONITOR = new Healthmonitors.StatusEnum("ACTIVE");

        public static final Healthmonitors.StatusEnum PENDING_CREATE = new Healthmonitors.StatusEnum("PENDING_CREATE");

        public static final Healthmonitors.StatusEnum ERROR = new Healthmonitors.StatusEnum("ERROR");

        private static final Map<String, Healthmonitors.StatusEnum> STATIC_FIELDS = createStaticFields();

        private static Map<String, Healthmonitors.StatusEnum> createStaticFields() {
            Map<String, Healthmonitors.StatusEnum> map = new HashMap<>();
            map.put("NO_MONITOR", NO_MONITOR);
            map.put("PENDING_CREATE", PENDING_CREATE);
            map.put("ERROR", ERROR);
            return Collections.unmodifiableMap(map);
        }

        private String value;

        StatusEnum(String value) {
            this.value = value;
        }

        @JsonValue
        public String getValue() {
            return String.valueOf(value);
        }

        @Override
        public String toString() {
            return String.valueOf(value);
        }

        @JsonCreator
        public static Healthmonitors.StatusEnum fromValue(String value) {
            if (value == null) {
                return null;
            }
            Healthmonitors.StatusEnum result = STATIC_FIELDS.get(value);
            if (result == null) {
                result = new Healthmonitors.StatusEnum(value);
            }
            return result;
        }

        public static Healthmonitors.StatusEnum valueOf(String value) {
            if (value == null) {
                return null;
            }
            Healthmonitors.StatusEnum result = STATIC_FIELDS.get(value);
            if (result != null) {
                return result;
            }
            throw new IllegalArgumentException("Unexpected value '" + value + "'");
        }

        @Override
        public boolean equals(Object obj) {
            if (obj != null && obj instanceof Healthmonitors.StatusEnum) {
                return this.value.equals(((Healthmonitors.StatusEnum) obj).value);
            }
            return false;
        }

        @Override
        public int hashCode() {
            return this.value.hashCode();

        }
    }

}
