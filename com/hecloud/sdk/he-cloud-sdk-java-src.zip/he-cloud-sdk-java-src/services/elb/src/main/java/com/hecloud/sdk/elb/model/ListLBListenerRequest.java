package com.hecloud.sdk.elb.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.With;

import java.util.List;

/**
 * @author 王凯
 * @date 2022/4/28
 */


@Data
@With
@AllArgsConstructor
@NoArgsConstructor
public class ListLBListenerRequest {
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="limit")

    private Integer limit;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="id")

    private List<String> id = null;


    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="loadbalancer_id")

    private List<String> loadbalancerId;


    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="marker")

    private String marker;


}
