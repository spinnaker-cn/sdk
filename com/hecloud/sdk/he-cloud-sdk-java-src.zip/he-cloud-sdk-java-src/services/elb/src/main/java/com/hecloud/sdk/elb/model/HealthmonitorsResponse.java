package com.hecloud.sdk.elb.model;


import com.huaweicloud.sdk.core.SdkResponse;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;


/**
 * @author 王凯
 * @date 2022/4/27
 */
@Data
@With
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
@ToString
public class HealthmonitorsResponse extends SdkResponse{
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="healthmonitors")

    private List<Healthmonitors> healthmonitors = null;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="healthmonitors_links")

    private List<Link> healthmonitorsLinks = null;
}
