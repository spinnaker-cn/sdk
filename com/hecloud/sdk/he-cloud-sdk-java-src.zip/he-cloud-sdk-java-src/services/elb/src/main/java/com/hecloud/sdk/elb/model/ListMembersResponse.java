package com.hecloud.sdk.elb.model;

import com.huaweicloud.sdk.core.SdkResponse;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.Objects;

/**
 * Response Object
 */
@Data
public class ListMembersResponse extends SdkResponse {




    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="members_links")

    private List<Link> membersLinks = null;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="members")

    private List<Member> members = null;

    public ListMembersResponse withMembers(List<Member> members) {
        this.members = members;
        return this;
    }

    public ListMembersResponse addMembersItem(Member membersItem) {
        this.members.add(membersItem);
        return this;
    }

    public ListMembersResponse withMembers(Consumer<List<Member>> membersSetter) {
        if(this.members == null ){
            this.members = new ArrayList<>();
        }
        membersSetter.accept(this.members);
        return this;
    }

    /**
     * 后端服务器对象列表。
     * @return members
     */
    public List<Member> getMembers() {
        return members;
    }

    public void setMembers(List<Member> members) {
        this.members = members;
    }



    @Override
    public boolean equals(java.lang.Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ListMembersResponse listMembersResponse = (ListMembersResponse) o;
        return Objects.equals(this.members, listMembersResponse.members);
    }
    @Override
    public int hashCode() {
        return Objects.hash(members);
    }
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class ListAllMembersResponse {\n");
        sb.append("    members: ").append(toIndentedString(members)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private String toIndentedString(java.lang.Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }

}

