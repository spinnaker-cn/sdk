package com.hecloud.sdk.elb.model;

import lombok.*;

/**
 * @author 硝酸铜
 * @date 2022/4/28
 */
@Data
@With
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
public class Link {
    private String href;

    /**
     * next / previous
     */
    private String rel;

    @Getter
    @AllArgsConstructor
    public static enum RelEnum{
        NEXT("next"),
        PREVIOUS("previous")
        ;
        private final String  rel;
    }
}
