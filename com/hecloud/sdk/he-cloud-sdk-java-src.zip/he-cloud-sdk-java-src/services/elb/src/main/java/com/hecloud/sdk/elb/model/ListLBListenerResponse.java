package com.hecloud.sdk.elb.model;

import com.huaweicloud.sdk.core.SdkResponse;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;


/**
 * @author 王凯
 * @date 2022/4/28
 */

@Data
@With
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
@ToString
public class ListLBListenerResponse  extends SdkResponse {
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="listeners")

    private List<LBListener> lblistener = null;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="listener_links")

    private List<Link> lblistenerLinks = null;


}
