import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.hecloud.sdk.elb.model.*;
import com.hecloud.sdk.elb.utils.LinkUtils;
import com.huaweicloud.sdk.core.auth.BasicCredentials;
import com.huaweicloud.sdk.core.http.HttpConfig;
import com.huaweicloud.sdk.core.region.Region;
import com.hecloud.sdk.elb.ElbClient;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * @author 硝酸铜
 * @date 2022/4/27
 */
public class Test {

    public static void main(String[] args) {

        String ak = System.getenv("HE_ACCOUNT_ACCESS_KEY_ID");
        String sk = System.getenv("HE_ACCOUNT_ACCESS_SECRET_KEY");
        String regionsName = System.getenv("HE_ACCOUNT_REGIONS_NAME");
        BasicCredentials auth = new BasicCredentials()
                .withAk(ak)
                .withSk(sk)
                .withIamEndpoint("https://iam." + regionsName + ".joint.cmecloud.cn");

        Region region = new Region(regionsName,"https://elb." + regionsName + ".joint.cmecloud.cn");
        ElbClient client = ElbClient.newBuilder()
                .withHttpConfig(HttpConfig.getDefaultHttpConfig())
                .withCredential(auth)
                .withRegion(region)
                .build();

        //testListL7policies(client);
        //testListLoadBalancers(client);
        //testListPools(client);
        //testShowPool(client);
        testlistListeners(client);
        //testhealthmonitors(client);
        //testListAllMembers(client);
    }

    public static void testListLoadBalancers(ElbClient client){

        List<String > ids = Lists.newArrayList("af659039-56d6-4aab-afe9-38eac9ab7caa","1716eb29-2ed2-4ca6-845f-d278f487ddf7");

        System.out.println(client.listLoadBalancers(new ListLoadBalancersRequest().withLimit(100).withId(ids)));
    }

    public static void testListPools(ElbClient client){
        List<String > ids = Lists.newArrayList("1716eb29-2ed2-4ca6-845f-d278f487ddf7","af659039-56d6-4aab-afe9-38eac9ab7caa");
        ListPoolsResponse response = client.listPools(new ListPoolsRequest().withLimit(2).withMarker("6509d220-9f63-4182-8332-476d00638e53").withLoadbalancerId(ids));
        System.out.println(response);
        System.out.println("marker: " + LinkUtils.getMarker(response.getPoolsLinks(),Link.RelEnum.NEXT));
    }

    public static void testShowPool(ElbClient client){
        String id = "f7cbe951-000c-4422-9679-fd048363becf";
        System.out.println( client.showPool(new ShowPoolRequest().withPoolId(id)));
    }


    public static void testListAllMembers(ElbClient client){

        ListMembersResponse response = client.listMembers(new ListMembersRequest().withPoolId("15d7e5b3-db48-48a6-821e-e61fd3648099").withLimit(100));
        System.out.println(response.toString());
    }


    public static void testListL7policies(ElbClient client){

        ListL7policiesResponse response = client.listL7policies(new ListL7policiesRequest());
        System.out.println(response.toString());
    }


    public static void testlistListeners(ElbClient client){

        //List<String > ids = new ArrayList<>();
        //ids.add("1ba11729-c0bb-472d-9ec9-0deb23a2b88a");
        //ids.add("749cdc87-fff3-4e79-b75c-1d34bc9ea578");
        //ids.add("af659039-56d6-4aab-afe9-38eac9ab7caa");

       ListLBListenerResponse response = client.listListeners(new ListLBListenerRequest());
        System.out.println(response.toString());
    }

    public static void testhealthmonitors(ElbClient client){

        HealthmonitorsResponse response = client.healthmonitors(new HealthmonitorsRequest());
        System.out.println(response.toString());
    }


}
