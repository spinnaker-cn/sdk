package com.hecloud.sdk.elb.model;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.Objects;

/**
 * 后端云服务器组列表查询返回对象。
 */
@Data
@With
@EqualsAndHashCode
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Member  {



    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="id")

    private String id;


    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="pool_id")

    private String poolId;


    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="name")

    private String name;


    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="tenant_id")

    private String tenantId;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="admin_state_up")

    private Boolean adminStateUp;


    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="protocol_port")

    private Integer protocolPort;


    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="weight")

    private Integer weight;


    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="address")

    private String address;



    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="subnet_id")

    private String subnetId;



    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="operating_status")

    private String operatingStatus;

}

