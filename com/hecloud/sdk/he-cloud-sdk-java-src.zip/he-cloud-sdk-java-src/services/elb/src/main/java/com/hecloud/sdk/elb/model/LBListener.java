package com.hecloud.sdk.elb.model;


import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.*;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * @author 王凯
 * @date 2022/4/28
 */

@Data
@EqualsAndHashCode
@With
@AllArgsConstructor
@NoArgsConstructor
public class LBListener {
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="id")
    private String id;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="name")

    private String name;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="protocol")
    private String protocol;


    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="protocol_port")

    private Integer protocolPort;


    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="default_tls_container_ref")

    private String defaultTlsContainerRef;


    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="client_ca_tls_container_ref")

    private String clientCaTlsContainerRef;

}
