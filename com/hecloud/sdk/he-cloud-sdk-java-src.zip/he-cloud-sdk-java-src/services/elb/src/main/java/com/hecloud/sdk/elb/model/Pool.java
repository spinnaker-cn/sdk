package com.hecloud.sdk.elb.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;

/**
 * @author 硝酸铜
 * @date 2022/4/28
 */
@Data
@With
@ToString
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
public class Pool {
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="id")

    private String id;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="name")

    private String name;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="loadbalancers")

    private List<LoadBalancerRef> loadbalancers = null;


    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="listeners")

    private List<ListenerRef> listeners = null;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="healthmonitor_id")

    private String healthmonitorId;
}
