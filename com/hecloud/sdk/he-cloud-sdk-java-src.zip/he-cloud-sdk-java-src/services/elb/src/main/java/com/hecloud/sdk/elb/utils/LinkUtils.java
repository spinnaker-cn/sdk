package com.hecloud.sdk.elb.utils;

import com.hecloud.sdk.elb.model.Link;

import java.util.List;

/**
 * 分页工具
 * @author 硝酸铜
 * @date 2022/4/28
 */
public class LinkUtils {

    /**
     * 根据response中上下页的链接信息,获取link href链接中的marker参数
     * @param link 链接对象
     * @return String
     */
    public static String getMarker(Link link){
        if(link == null || link.getHref() == null || "".equals(link.getHref())){
            return null;
        }
        String[] requestParams = link.getHref().split("\\?")[1].split("&");
        for (String requestParam : requestParams) {
            String[] param = requestParam.split("=");
            if ("marker".equals(param[0])) {
                return param[1];
            }
        }
        return null;
    }

    /**
     * 根据response中上下页的链接信息,获取link href链接中的marker参数
     * @param links 链接集合
     * @param rel 枚举，指定需要获取的的是上一页还是下一页的marker参数
     * @return String
     */
    public static String getMarker(List<Link> links , Link.RelEnum rel){
        if(links == null){
            return null;
        }
        if(hasNextOrPrevious(links,rel)){
            for (Link link : links){
                if(rel.getRel().equals(link.getRel())){
                    return getMarker(link);
                }
            }
        }
        return null;
    }


    /**
     * 判断是否是下一页或者上一页
     * @param links 链接对象
     * @param rel 枚举，指定需要判断的是上一页还是下一页
     * @return Boolean
     */
    public static Boolean hasNextOrPrevious(List<Link> links, Link.RelEnum rel){
        if(links == null){
            return false;
        }

        for (Link link:links) {
            if(rel.getRel().equals(link.getRel())){
                return true;
            }
        }
        return false;
    }
}
