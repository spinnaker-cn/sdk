package com.hecloud.sdk.elb.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.With;

/**
 * @author 硝酸铜
 * @date 2022/4/28
 */
@Data
@With
@AllArgsConstructor
@NoArgsConstructor
public class ShowPoolRequest {
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="pool_id")

    private String poolId;
}
