package com.hecloud.sdk.elb;

import com.hecloud.sdk.elb.model.*;
import com.huaweicloud.sdk.core.ClientBuilder;
import com.huaweicloud.sdk.core.HcClient;

/**
 * @author 硝酸铜
 * @date 2022/4/27
 */
public class ElbClient {

    protected HcClient hcClient;

    public ElbClient(HcClient hcClient) {
        this.hcClient = hcClient;
    }

    public static ClientBuilder<ElbClient> newBuilder() {
        return new ClientBuilder<>(ElbClient::new);
    }

    /**
     * 查询负载均衡器列表
     *
     * @param request 请求对象
     * @return ListLoadBalancersResponse
     */
    public ListLoadBalancersResponse listLoadBalancers(ListLoadBalancersRequest request) {
        return hcClient.syncInvokeHttp(request, ElbMeta.listLoadBalancers);
    }


    /**
     * 查询后端服务器列表
     *
     * @param request 请求对象
     * @return ListMembersResponse
     */
    public ListMembersResponse listMembers(ListMembersRequest request) {
        return hcClient.syncInvokeHttp(request, ElbMeta.listMembers);
    }



    /**
     * 查询转发策略
     *
     * @param request 请求对象
     * @return ListL7policiesResponse
     */
    public ListL7policiesResponse listL7policies(ListL7policiesRequest request) {
        return hcClient.syncInvokeHttp(request, ElbMeta.listL7policies);

    }


    /**
     * 查询后端服务器组列表
     * 后端服务器组列表。
     *
     * @param request 请求对象
     * @return ListPoolsResponse
     */
    public ListPoolsResponse listPools(ListPoolsRequest request) {
        return hcClient.syncInvokeHttp(request, ElbMeta.listPools);
    }

    /**
     * 查询后端服务器组详情
     * 后端服务器组详情。
     *
     * @param request 请求对象
     * @return ShowPoolResponse
     */
    public ShowPoolResponse showPool(ShowPoolRequest request) {
        return hcClient.syncInvokeHttp(request, ElbMeta.showPool);
    }

    /**
     * 查询监听器列表
     *
     * @param request 请求对象
     * @return ListLBListenerResponse
     */
    public ListLBListenerResponse listListeners(ListLBListenerRequest request) {
        return hcClient.syncInvokeHttp(request, ElbMeta.lblistener);
    }

    /**
     * 查询健康检查
     *
     * @param request 请求对象
     * @return ListLBListenerResponse
     */
    public HealthmonitorsResponse healthmonitors(HealthmonitorsRequest request) {
        return hcClient.syncInvokeHttp(request, ElbMeta.healthmonitors);
    }


}
