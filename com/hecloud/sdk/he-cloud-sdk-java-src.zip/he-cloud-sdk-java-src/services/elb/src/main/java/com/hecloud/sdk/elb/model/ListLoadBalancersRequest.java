package com.hecloud.sdk.elb.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.With;

import java.util.List;

/**
 * @author 硝酸铜
 * @date 2022/4/27
 */

@Data
@With
@AllArgsConstructor
@NoArgsConstructor
public class ListLoadBalancersRequest {
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="marker")

    private String marker;


    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="limit")

    private Integer limit;



    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="id")

    private List<String> id = null;


}
