package com.hecloud.sdk.elb.model;

import com.huaweicloud.sdk.core.SdkResponse;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.Objects;

/**
 * Response Object
 */

@Data
@With
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
@ToString
public class ListL7policiesResponse extends SdkResponse {


    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="l7policies_links")

    private List<Link> l7policiesLinks = null;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="l7policies")

    private List<L7policyResp> l7policies = null;

}

