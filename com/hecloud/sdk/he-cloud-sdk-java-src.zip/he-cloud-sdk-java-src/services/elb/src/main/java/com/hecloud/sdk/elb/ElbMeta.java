package com.hecloud.sdk.elb;

import com.hecloud.sdk.elb.model.*;
import com.huaweicloud.sdk.core.http.FieldExistence;
import com.huaweicloud.sdk.core.http.HttpMethod;
import com.huaweicloud.sdk.core.http.HttpRequestDef;
import com.huaweicloud.sdk.core.http.LocationType;

import java.util.List;

/**
 * @author 硝酸铜
 * @date 2022/4/27
 */
public class ElbMeta {
    public static final HttpRequestDef<ListLoadBalancersRequest, ListLoadBalancersResponse> listLoadBalancers = genForlistLoadBalancers();

    private static HttpRequestDef<ListLoadBalancersRequest, ListLoadBalancersResponse> genForlistLoadBalancers() {
        // basic
        HttpRequestDef.Builder<ListLoadBalancersRequest, ListLoadBalancersResponse> builder =
                HttpRequestDef.builder(HttpMethod.GET, ListLoadBalancersRequest.class, ListLoadBalancersResponse.class)
                        .withUri("/v2.0/lbaas/loadbalancers")
                        .withContentType("application/json");


        builder.withRequestField("marker",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                String.class,
                f -> f.withMarshaller(ListLoadBalancersRequest::getMarker, ListLoadBalancersRequest::setMarker)
        );

        builder.withRequestField("limit",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                Integer.class,
                f -> f.withMarshaller(ListLoadBalancersRequest::getLimit, ListLoadBalancersRequest::setLimit)
        );

        builder.withRequestField("id",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                List.class,
                f -> f.withMarshaller(ListLoadBalancersRequest::getId, ListLoadBalancersRequest::setId)
        );


        return builder.build();
    }



    public static final HttpRequestDef<ListMembersRequest, ListMembersResponse> listMembers = genForlistMembers();

    private static HttpRequestDef<ListMembersRequest, ListMembersResponse> genForlistMembers() {
        // basic
        HttpRequestDef.Builder<ListMembersRequest, ListMembersResponse> builder =
                HttpRequestDef.builder(HttpMethod.GET, ListMembersRequest.class, ListMembersResponse.class)
                        .withUri("/v2.0/lbaas/pools/{pool_id}/members")
                        .withContentType("application/json");

        // requests
        builder.withRequestField("pool_id",
                LocationType.Path,
                FieldExistence.NULL_IGNORE,
                String.class,
                f -> f.withMarshaller(ListMembersRequest::getPoolId, (req, v) -> {
                    req.setPoolId(v);
                })
        );
        builder.withRequestField("marker",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                String.class,
                f -> f.withMarshaller(ListMembersRequest::getMarker, (req, v) -> {
                    req.setMarker(v);
                })
        );
        builder.withRequestField("limit",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                Integer.class,
                f -> f.withMarshaller(ListMembersRequest::getLimit, (req, v) -> {
                    req.setLimit(v);
                })
        );
        builder.withRequestField("tenant_id",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                String.class,
                f -> f.withMarshaller(ListMembersRequest::getTenantId, (req, v) -> {
                    req.setTenantId(v);
                })
        );
        builder.withRequestField("id",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                String.class,
                f -> f.withMarshaller(ListMembersRequest::getId, (req, v) -> {
                    req.setId(v);
                })
        );


        builder.withRequestField("address",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                String.class,
                f -> f.withMarshaller(ListMembersRequest::getAddress, (req, v) -> {
                    req.setAddress(v);
                })
        );
        builder.withRequestField("admin_state_up",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                String.class,
                f -> f.withMarshaller(ListMembersRequest::getAdminStateUp, (req, v) -> {
                    req.setAdminStateUp(v);
                })
        );


        builder.withRequestField("name",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                String.class,
                f -> f.withMarshaller(ListMembersRequest::getName, (req, v) -> {
                    req.setName(v);
                })
        );

        builder.withRequestField("page_reverse",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                Boolean.class,
                f -> f.withMarshaller(ListMembersRequest::getPageReverse, (req, v) -> {
                    req.setPageReverse(v);
                })
        );
        builder.withRequestField("protocol_port",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                Integer.class,
                f -> f.withMarshaller(ListMembersRequest::getProtocolPort, (req, v) -> {
                    req.setProtocolPort(v);
                })
        );
        builder.withRequestField("subnet_id",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                String.class,
                f -> f.withMarshaller(ListMembersRequest::getSubnetId, (req, v) -> {
                    req.setSubnetId(v);
                })
        );
        builder.withRequestField("weight",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                Integer.class,
                f -> f.withMarshaller(ListMembersRequest::getWeight, (req, v) -> {
                    req.setWeight(v);
                })
        );

        // response

        return builder.build();
    }



    public static final HttpRequestDef<ListL7policiesRequest, ListL7policiesResponse> listL7policies = genForlistL7policies();

    private static HttpRequestDef<ListL7policiesRequest, ListL7policiesResponse> genForlistL7policies() {
        // basic
        HttpRequestDef.Builder<ListL7policiesRequest, ListL7policiesResponse> builder =
                HttpRequestDef.builder(HttpMethod.GET, ListL7policiesRequest.class, ListL7policiesResponse.class)
                        .withUri("/v2.0/lbaas/l7policies")
                        .withContentType("application/json");

        // requests
        builder.withRequestField("limit",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                Integer.class,
                f -> f.withMarshaller(ListL7policiesRequest::getLimit, (req, v) -> {
                    req.setLimit(v);
                })
        );
        builder.withRequestField("tenant_id",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                String.class,
                f -> f.withMarshaller(ListL7policiesRequest::getTenantId, (req, v) -> {
                    req.setTenantId(v);
                })
        );
        builder.withRequestField("marker",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                String.class,
                f -> f.withMarshaller(ListL7policiesRequest::getMarker, (req, v) -> {
                    req.setMarker(v);
                })
        );
        builder.withRequestField("page_reverse",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                Boolean.class,
                f -> f.withMarshaller(ListL7policiesRequest::getPageReverse, (req, v) -> {
                    req.setPageReverse(v);
                })
        );
        builder.withRequestField("id",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                String.class,
                f -> f.withMarshaller(ListL7policiesRequest::getId, (req, v) -> {
                    req.setId(v);
                })
        );
        builder.withRequestField("name",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                String.class,
                f -> f.withMarshaller(ListL7policiesRequest::getName, (req, v) -> {
                    req.setName(v);
                })
        );
        builder.withRequestField("description",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                String.class,
                f -> f.withMarshaller(ListL7policiesRequest::getDescription, (req, v) -> {
                    req.setDescription(v);
                })
        );
        builder.withRequestField("admin_state_up",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                Boolean.class,
                f -> f.withMarshaller(ListL7policiesRequest::getAdminStateUp, (req, v) -> {
                    req.setAdminStateUp(v);
                })
        );
        builder.withRequestField("listener_id",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                List.class,
                f -> f.withMarshaller(ListL7policiesRequest::getListenerId, (req, v) -> {
                    req.setListenerId(v);
                })
        );
        builder.withRequestField("action",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                String.class,
                f -> f.withMarshaller(ListL7policiesRequest::getAction, (req, v) -> {
                    req.setAction(v);
                })
        );
        builder.withRequestField("redirect_pool_id",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                String.class,
                f -> f.withMarshaller(ListL7policiesRequest::getRedirectPoolId, (req, v) -> {
                    req.setRedirectPoolId(v);
                })
        );
        builder.withRequestField("redirect_listener_id",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                String.class,
                f -> f.withMarshaller(ListL7policiesRequest::getRedirectListenerId, (req, v) -> {
                    req.setRedirectListenerId(v);
                })
        );
        builder.withRequestField("redirect_url",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                String.class,
                f -> f.withMarshaller(ListL7policiesRequest::getRedirectUrl, (req, v) -> {
                    req.setRedirectUrl(v);
                })
        );
        builder.withRequestField("position",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                Integer.class,
                f -> f.withMarshaller(ListL7policiesRequest::getPosition, (req, v) -> {
                    req.setPosition(v);
                })
        );
        builder.withRequestField("provisioning_status",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                String.class,
                f -> f.withMarshaller(ListL7policiesRequest::getProvisioningStatus, (req, v) -> {
                    req.setProvisioningStatus(v);
                })
        );
        builder.withRequestField("enterprise_project_id",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                String.class,
                f -> f.withMarshaller(ListL7policiesRequest::getEnterpriseProjectId, (req, v) -> {
                    req.setEnterpriseProjectId(v);
                })
        );
        builder.withRequestField("display_all_rules",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                Boolean.class,
                f -> f.withMarshaller(ListL7policiesRequest::getDisplayAllRules, (req, v) -> {
                    req.setDisplayAllRules(v);
                })
        );

        // response
        return builder.build();
    }
    public static final HttpRequestDef<ListPoolsRequest, ListPoolsResponse> listPools = genForlistPools();

    private static HttpRequestDef<ListPoolsRequest, ListPoolsResponse> genForlistPools() {
        HttpRequestDef.Builder<ListPoolsRequest, ListPoolsResponse> builder =
                HttpRequestDef.builder(HttpMethod.GET, ListPoolsRequest.class, ListPoolsResponse.class)
                        .withUri("/v2.0/lbaas/pools")
                        .withContentType("application/json");

        builder.withRequestField("loadbalancer_id",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                List.class,
                f -> f.withMarshaller(ListPoolsRequest::getLoadbalancerId, ListPoolsRequest::setLoadbalancerId)
        );
        builder.withRequestField("marker",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                String.class,
                f -> f.withMarshaller(ListPoolsRequest::getMarker, ListPoolsRequest::setMarker)
        );

        builder.withRequestField("limit",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                Integer.class,
                f -> f.withMarshaller(ListPoolsRequest::getLimit, ListPoolsRequest::setLimit)
        );

        return builder.build();
    }

    public static final HttpRequestDef<ShowPoolRequest, ShowPoolResponse> showPool = genForshowPool();

    private static HttpRequestDef<ShowPoolRequest, ShowPoolResponse> genForshowPool() {
        // basic
        HttpRequestDef.Builder<ShowPoolRequest, ShowPoolResponse> builder =
                HttpRequestDef.builder(HttpMethod.GET, ShowPoolRequest.class, ShowPoolResponse.class)
                        .withUri("/v2.0/lbaas/pools/{pool_id}")
                        .withContentType("application/json");

        builder.withRequestField("pool_id",
                LocationType.Path,
                FieldExistence.NON_NULL_NON_EMPTY,
                String.class,
                f -> f.withMarshaller(ShowPoolRequest::getPoolId, ShowPoolRequest::setPoolId)
        );

        return builder.build();
    }



    public static final HttpRequestDef<ListLBListenerRequest, ListLBListenerResponse> lblistener = genForlistlblistener();

    private static HttpRequestDef<ListLBListenerRequest, ListLBListenerResponse> genForlistlblistener() {
        // basic
        HttpRequestDef.Builder<ListLBListenerRequest, ListLBListenerResponse> builder =
                HttpRequestDef.builder(HttpMethod.GET, ListLBListenerRequest.class, ListLBListenerResponse.class)
                        .withUri("/v2.0/lbaas/listeners")
                        .withContentType("application/json");

        builder.withRequestField("loadbalancer_id",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                List.class,
                f -> f.withMarshaller(ListLBListenerRequest::getLoadbalancerId, ListLBListenerRequest::setLoadbalancerId)
        );

        builder.withRequestField("marker",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                String.class,
                f -> f.withMarshaller(ListLBListenerRequest::getMarker, ListLBListenerRequest::setMarker)
        );

        builder.withRequestField("limit",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                Integer.class,
                f -> f.withMarshaller(ListLBListenerRequest::getLimit, ListLBListenerRequest::setLimit)
        );

        builder.withRequestField("id",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                List.class,
                f -> f.withMarshaller(ListLBListenerRequest::getId, ListLBListenerRequest::setId)
        );


        return builder.build();
    }


    public static final HttpRequestDef<HealthmonitorsRequest, HealthmonitorsResponse> healthmonitors = genForHealthmonitorsr();

    private static HttpRequestDef<HealthmonitorsRequest, HealthmonitorsResponse> genForHealthmonitorsr() {
        // basic
        HttpRequestDef.Builder<HealthmonitorsRequest, HealthmonitorsResponse> builder =
                HttpRequestDef.builder(HttpMethod.GET, HealthmonitorsRequest.class, HealthmonitorsResponse.class)
                        .withUri("/v2.0/lbaas/healthmonitors")
                        .withContentType("application/json");

        builder.withRequestField("marker",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                String.class,
                f -> f.withMarshaller(HealthmonitorsRequest::getMarker, HealthmonitorsRequest::setMarker)
        );

        builder.withRequestField("limit",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                Integer.class,
                f -> f.withMarshaller(HealthmonitorsRequest::getLimit, HealthmonitorsRequest::setLimit)
        );

        builder.withRequestField("id",
                LocationType.Query,
                FieldExistence.NULL_IGNORE,
                List.class,
                f -> f.withMarshaller(HealthmonitorsRequest::getId, HealthmonitorsRequest::setId)
        );

        return builder.build();
    }


}
