package com.hecloud.sdk.elb.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.With;

/**
 * @author 硝酸铜
 * @date 2022/4/27
 */

@Data
@With
@AllArgsConstructor
@NoArgsConstructor
public class ListMembersRequest {

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="pool_id")

    private String poolId = null;


    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="marker")

    private String marker;


    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="limit")

    private Integer limit;



    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="tenant_id")

    private String tenantId;


    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="id")

    private String id = null;



    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="name")

    private String name = null;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="address")

    private String address = null;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="admin_state_up")

    private String adminStateUp = null;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="page_reverse")

    private Boolean pageReverse = false;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="protocol_port")

    private Integer protocolPort;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="weight")

    private Integer weight;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value="subnet_id")

    private String subnetId = null;
}
